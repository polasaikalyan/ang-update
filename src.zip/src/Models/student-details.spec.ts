import { StudentDetails } from './student-details';

describe('StudentDetails', () => {
  it('should create an instance', () => {
    expect(new StudentDetails()).toBeTruthy();
  });
});
