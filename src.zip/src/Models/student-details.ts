export class StudentDetails {
    StudentId : number
    StudentName : string
    Gender : string
    DOB : Date
    PhoneNumber : string
    Address : string
    Password : string
    EmailId : string
    HighSchoolMarks :number
    IntermediateMarks :number
    GraduationCourse :string
    GraduationPercentage : number
    
}
