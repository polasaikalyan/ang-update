import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import {AdminLoginDetailService} from '../../../Services/admin-login-detail.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  loginForm: FormGroup;
  submitted = false;

  constructor(private formBuilder : FormBuilder, private router : Router, private service : AdminLoginDetailService) { }

  ngOnInit() {
    this.loginForm = this.formBuilder.group({
    username: ['', Validators.required],
    password: ['', Validators.required]
});
  }
  get f() { return this.loginForm.controls; }

  onSubmit(){
    this.submitted = true;
    if (this.loginForm.invalid) {
      return;
    }
    this.service.CheckAdminLogin(this.f.username.value, this.f.password.value).subscribe(
      data => {
        this.router.navigate(['managestudents']);
      },error => {alert(error["error"]);}
    )
  }
}
