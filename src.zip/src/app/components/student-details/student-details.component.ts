import { Component, OnInit, ViewChild, AfterViewInit  } from '@angular/core';
import {MatTableDataSource} from '@angular/material/table';
import { StudentDetails } from '../../../Models/student-details';
import { MatSort, MatPaginator } from '@angular/material';

import { Router } from '@angular/router';
import { StudentDetailsService } from '../../..//Services/student-details.service';

@Component({
  selector: 'app-student-details',
  templateUrl: './student-details.component.html',
  styleUrls: ['./student-details.component.css']
})
export class StudentDetailsComponent implements OnInit {
  displayedColumns : string[] = ['StudentName','Gender','DOB','PhoneNumber','Address','EmailId','HighSchoolMarks','IntermediateMarks','GraduationCourse','GraduationPercentage'];
  students : any;
  dataSource : MatTableDataSource<any>;

  @ViewChild(MatSort, {static: false}) sort: MatSort;
  @ViewChild(MatPaginator, {static: false}) paginator: MatPaginator;

  constructor(private service : StudentDetailsService, private router : Router) { }

  ngOnInit() {
    this.getdata();
  }
  getdata(){
    this.service.GetAllStudents().subscribe(
      data => {
          this.dataSource = new MatTableDataSource(data as StudentDetails[]);
          this.dataSource.sort = this.sort;
          this.dataSource.paginator = this.paginator;
          this.dataSource.filterPredicate = (list, filter) => {
            console.log(typeof(list), filter);
             return this.displayedColumns.some(ele => {
               return ele != "Actions" && list[ele].toString().toLowerCase().indexOf(filter) != -1;
            }
            )
          };
       }
    )
  }

  applyFilter(searchValue : string){
    this.dataSource.filter = searchValue.trim().toLowerCase();
    
  }


  
}
