import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { StudentDetailsComponent } from './components/student-details/student-details.component';
import { LoginComponent } from './components/login/login.component';


const routes: Routes = [
  {path:'managestudents', component:StudentDetailsComponent},
  {path:'login', component:LoginComponent},
  { path: '',  redirectTo: '/login',  pathMatch: 'full'}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
