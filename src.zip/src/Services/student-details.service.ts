import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { StudentDetails } from '../models/student-details';

@Injectable({
  providedIn: 'root'
})
export class StudentDetailsService {

  constructor(private http : HttpClient) { }

  student : StudentDetails;

  public GetAllStudents(){
    return this.http.get<StudentDetails[]>('https://localhost:44347/api/StudentDetails/GetStudentDetails');
  }

}
