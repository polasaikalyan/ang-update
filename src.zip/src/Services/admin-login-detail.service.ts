import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

import { AdminLoginDetail } from '../Models/admin-login-detail';
import { StudentDetails } from '../Models/student-details';

import { NgForm } from '@angular/forms';

@Injectable({
  providedIn: 'root'
})

export class AdminLoginDetailService {

  constructor(private http : HttpClient) { }
  student : StudentDetails;


  public CheckAdminLogin(username : string, password : string){
    return this.http.get('https://localhost:44347/api/Login/AdminLogin?username=' + username + '&password=' + password);
  }

}
