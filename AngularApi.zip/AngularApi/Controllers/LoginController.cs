﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using AngularApi.Models;

namespace AngularApi.Controllers
{
    public class LoginController : ApiController
    {
        private SaiKalyanEntities db = new SaiKalyanEntities();

        [HttpGet]
        public HttpResponseMessage AdminLogin(string username, string password)
        {
            var IsAdminExists = db.AdminDetails.Where(a => a.Username == username).SingleOrDefault();
            if (IsAdminExists != null)
            {
                if (IsAdminExists.Password == password)
                {
                    return Request.CreateResponse(HttpStatusCode.OK, IsAdminExists);
                }
                else
                {
                    return Request.CreateResponse(HttpStatusCode.NotFound, "Password InCorrect");
                }
            }
            else
            {
                return Request.CreateResponse(HttpStatusCode.NotFound, "Username Not Found");
            }
        }
    }
}
